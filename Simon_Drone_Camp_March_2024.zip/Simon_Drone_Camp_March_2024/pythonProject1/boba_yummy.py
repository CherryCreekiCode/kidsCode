best_boba = ["1. boba","2. bobatea","3. tea","4. milk_tea","5. boba_milk_tea","6. milk"]
print("here is the menu:")
for item in best_boba:
    print(item)

num = int(input("enter your number: "))
boba = num % 2
if boba == 1:
    for i in range(6):
        if i % 2 == 0:
            print(best_boba[i])
        else:
            continue
else:
    for i in range(6):
        if i % 2 == 1:
            print(best_boba[i])
        else:
            continue
