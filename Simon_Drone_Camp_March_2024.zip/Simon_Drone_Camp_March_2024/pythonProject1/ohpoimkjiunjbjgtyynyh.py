from easytello import tello

myDrone = tello.Tello()


myDrone.get_battery()
print(myDrone.get_battery())
myDrone.get_baro()
print(myDrone.get_baro())
myDrone.get_time()
print(myDrone.get_time())
myDrone.get_attitude()
print(myDrone.get_attitude())
myDrone.get_temp()
print(myDrone.get_temp())

