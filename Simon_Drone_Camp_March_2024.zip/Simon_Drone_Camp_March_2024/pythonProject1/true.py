stop = 100000000
start = 0
while start <= stop:
    print("start", start)

    start += 1
