def even(n):
    for i in range(n):
        print("this number is even.")
def odd(n):
    for i in range(n):
        print("this number is odd.")

num = int(input("enter any number less than 100."))

if (num % 2) == 0:
    even(num)
else:
    odd(num)