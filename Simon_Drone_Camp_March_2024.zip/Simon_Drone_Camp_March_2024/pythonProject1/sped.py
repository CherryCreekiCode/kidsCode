from easytello import tello

myDrone = tello.Tello()
def speed():
    myDrone.set_speed(100)
    myDrone.forward(250)
def slow():
    myDrone.set_speed(50)
    myDrone.back(250)

myDrone.takeoff()
speed()
myDrone.wait(2)
slow()
myDrone.wait(2)
myDrone.land()