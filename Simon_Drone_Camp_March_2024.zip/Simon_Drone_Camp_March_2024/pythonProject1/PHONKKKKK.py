
temperature = 12
print(temperature)
if temperature < 32:

    print("water will freeze")
else:
    print("water will not freeze")
temperature = temperature + 5
print(temperature)
