from easytello import tello

myDrone = tello.Tello()
def flightPath():
    myDrone.takeoff()
    myDrone.wait(1)
    myDrone.flip('f')
    myDrone.forward(300)
    myDrone.cw(180)
    myDrone.forward(300)
    myDrone.land()



flightPath()


