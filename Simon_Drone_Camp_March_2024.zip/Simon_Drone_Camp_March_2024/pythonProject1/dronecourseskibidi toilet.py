from easytello import tello

myDrone = tello.Tello()

distance = int(input("Enter the distance in cm: "))
print(distance)

myDrone.takeoff()
myDrone.get_battery()
myDrone._video_thread()
myDrone.curve(0, 0, 0, 0, 50, 0, 5)
myDrone.forward(distance)
myDrone.land()
